#include <iostream>
#include <string>
using namespace std;

class ResourceManager;
class CrewManager;
class MissionManager;
class VehicleManager;

struct CrewMember;
struct Vehicle;
struct Mission;
struct Resource;

enum ResourceType
{
    FUEL,
    FOOD,
    WATER,
    MEDICAL_SUPPLIES,
    TECHNOLOGY,
    MATERIALS
};

enum MissionType
{
    EXPLORATION,
    TRANSPORT,
    DEFENSE,
    REPAIR,
    COLONIZATION
};

enum VehicleType
{
    SHUTTLE,
    ROVER,
    SPACE_STATION,
    FREIGHTER,
    PROBE
};

struct Resource
{
    ResourceType type;
    double quantity;
    double value;
    string expirationDate;

    bool consume(double amount)
    {
        if (quantity < amount)
        {
            cout << "No more quantity left...\n";
            return false;
        }

        quantity -= amount;
        return true;
    }
};

struct CrewMember
{
    string name;
    string role;
    string rank;
    int experienceYears;
    Mission *assignedMissions[10];
    int missionCounter = 0;

    bool assignMission(Mission *mission)
    {
        if (missionCounter < 10 && mission != nullptr)
        {
            assignedMissions[missionCounter++] = mission;
            return true;
        }
        else
        {
            cout << "Can't assign more than 10 missions to this crew member.\n";
            return false;
        }
    }

    void displayInfo()
    {
        cout << "Crew Member Name: " << name << "\nRole: " << role << "\nRank: " << rank << "\nExperience: " << experienceYears << " years\n";
    }
};

struct Vehicle
{
    string name;
    VehicleType type;
    double fuelLevel;
    int crewCapacity = 0;
    CrewMember *currentCrew[10];

    bool refuel(double amount)
    {
        if (amount <= 0)
        {
            cout << "Invalid refuel amount.\n";
            return false;
        }

        fuelLevel += amount;
        return true;
    }

    bool assignCrew(CrewMember *member)
    {
        if (crewCapacity >= 10 || member == nullptr)
        {
            cout << "Can't assign crew to vehicle. Capacity full or invalid member.\n";
            return false;
        }

        currentCrew[crewCapacity++] = member;
        return true;
    }
};

struct Mission
{
    string name;
    MissionType type;
    string startDate;
    string endDate;
    string status;
    int numAssignedCrews = 0;
    CrewMember *assignedCrew[10];
    Vehicle *assignedVehicle;

    void assignCrewMember(CrewMember *member)
    {
        if (numAssignedCrews < 10 && member != nullptr)
        {
            assignedCrew[numAssignedCrews++] = member;
            return;
        }
        cout << "Can't assign crew member to mission.\n";
    }

    bool updateMissionStatus(string newStatus)
    {
        status = newStatus;
        return true;
    }

    string getName()
    {
        return name;
    }

    void displayMissionDetails()
    {
        cout << "\n=== Mission Details ===\n"
             << "Name: " << name << "\nType: ";
        switch (type)
        {
        case EXPLORATION:
            cout << "EXPLORATION";
            break;
        case TRANSPORT:
            cout << "TRANSPORT";
            break;
        case DEFENSE:
            cout << "DEFENSE";
            break;
        case REPAIR:
            cout << "REPAIR";
            break;
        case COLONIZATION:
            cout << "COLONIZATION";
            break;
        default:
            cout << "UNKNOWN";
        }
        cout << "\nDates: " << startDate << " to " << endDate
             << "\nStatus: " << status
             << "\nAssigned Crew: ";
        for (int i = 0; i < numAssignedCrews; i++)
        {
            if (assignedCrew[i] != nullptr)
                cout << assignedCrew[i]->name << ", ";
        }
        cout << "\nVehicle: ";
        if (assignedVehicle != nullptr)
            cout << assignedVehicle->name;
        else
            cout << "None";
        cout << "\n";
    }
};

class ResourceManager
{
public:
    Resource *resources[10] = {nullptr};
    int numberResourcesAdded = 0;

    bool addResource(Resource *resource)
    {
        if (numberResourcesAdded >= 10 || resource == nullptr)
        {
            cout << "Can't add resource.\n";
            return false;
        }
        resources[numberResourcesAdded++] = resource;
        return true;
    }

    void consumeResource(string resourceName, double amount)
    {
        ResourceType targetType;
        if (resourceName == "FUEL")
            targetType = FUEL;
        else if (resourceName == "FOOD")
            targetType = FOOD;
        else if (resourceName == "WATER")
            targetType = WATER;
        else if (resourceName == "MEDICAL_SUPPLIES")
            targetType = MEDICAL_SUPPLIES;
        else if (resourceName == "TECHNOLOGY")
            targetType = TECHNOLOGY;
        else if (resourceName == "MATERIALS")
            targetType = MATERIALS;
        else
        {
            cout << "Invalid resource name.\n";
            return;
        }

        bool consumed = false;
        for (int i = 0; i < numberResourcesAdded && !consumed; i++)
        {
            if (resources[i]->type == targetType)
            {
                if (resources[i]->consume(amount))
                    cout << "Consumed " << amount << " units of " << resourceName << ".\n";
                else
                    cout << "Failed to consume " << resourceName << ".\n";
                consumed = true;
            }
        }
        if (!consumed)
            cout << resourceName << " not found.\n";
    }

    void replenishResource(string resourceName, double amount)
    {
        ResourceType targetType;
        if (resourceName == "FUEL")
            targetType = FUEL;
        else if (resourceName == "FOOD")
            targetType = FOOD;
        else if (resourceName == "WATER")
            targetType = WATER;
        else if (resourceName == "MEDICAL_SUPPLIES")
            targetType = MEDICAL_SUPPLIES;
        else if (resourceName == "TECHNOLOGY")
            targetType = TECHNOLOGY;
        else if (resourceName == "MATERIALS")
            targetType = MATERIALS;
        else
        {
            cout << "Invalid resource name.\n";
            return;
        }

        bool found = false;
        for (int i = 0; i < numberResourcesAdded && !found; i++)
        {
            if (resources[i]->type == targetType)
            {
                resources[i]->quantity += amount;
                found = true;
                cout << "Replenished " << amount << " units of " << resourceName << ".\n";
            }
        }
        if (!found)
            cout << resourceName << " not found.\n";
    }

    void displayResources()
    {
        if (numberResourcesAdded == 0)
        {
            cout << "No resources available.\n";
            return;
        }
        cout << "\n=== Resources ===\n";
        for (int i = 0; i < numberResourcesAdded; i++)
        {
            string typeStr;
            switch (resources[i]->type)
            {
            case FUEL:
                typeStr = "FUEL";
                break;
            case FOOD:
                typeStr = "FOOD";
                break;
            case WATER:
                typeStr = "WATER";
                break;
            case MEDICAL_SUPPLIES:
                typeStr = "MEDICAL_SUPPLIES";
                break;
            case TECHNOLOGY:
                typeStr = "TECHNOLOGY";
                break;
            case MATERIALS:
                typeStr = "MATERIALS";
                break;
            default:
                typeStr = "UNKNOWN";
            }
            cout << typeStr << ": " << resources[i]->quantity << " units\n";
        }
    }
};

class CrewManager
{
public:
    CrewMember *crew[10];
    int numofCrewMemAdded = 0;

    bool addCrewMember(CrewMember *member)
    {
        if (numofCrewMemAdded >= 10 || member == nullptr)
        {
            cout << "Can't add crew member.\n";
            return false;
        }
        crew[numofCrewMemAdded++] = member;
        return true;
    }

    void assignCrewToMission(string crewName, Mission *mission)
    {
        if (mission == nullptr)
        {
            cout << "Invalid mission.\n";
            return;
        }

        for (int i = 0; i < numofCrewMemAdded; i++)
        {
            if (crew[i]->name == crewName)
            {
                if (crew[i]->assignMission(mission))
                {
                    mission->assignCrewMember(crew[i]);
                    cout << "Assigned " << crewName << " to mission.\n";
                }
                return;
            }
        }
        cout << "Crew member " << crewName << " not found.\n";
    }

    void displayCrewInfo()
    {
        if (numofCrewMemAdded == 0)
        {
            cout << "No crew members.\n";
            return;
        }
        cout << "\n=== Crew Members ===\n";
        for (int i = 0; i < numofCrewMemAdded; i++)
        {
            crew[i]->displayInfo();
            cout << "--------------------\n";
        }
    }
};

class VehicleManager
{
public:
    Vehicle *vehicles[10];
    int numofVehiclesAdded = 0;

    bool addVehicle(Vehicle *vehicle)
    {
        if (numofVehiclesAdded >= 10 || vehicle == nullptr)
        {
            cout << "Can't add vehicle.\n";
            return false;
        }
        vehicles[numofVehiclesAdded++] = vehicle;
        return true;
    }

    void assignCrewToVehicle(string vehicleName, CrewMember *member)
    {
        if (member == nullptr)
        {
            cout << "Invalid crew member.\n";
            return;
        }

        for (int i = 0; i < numofVehiclesAdded; i++)
        {
            if (vehicles[i]->name == vehicleName)
            {
                if (vehicles[i]->assignCrew(member))
                    cout << "Assigned " << member->name << " to " << vehicleName << ".\n";
                return;
            }
        }
        cout << "Vehicle " << vehicleName << " not found.\n";
    }

    void refuelVehicle(string vehicleName, double amount)
    {
        for (int i = 0; i < numofVehiclesAdded; i++)
        {
            if (vehicles[i]->name == vehicleName)
            {
                if (vehicles[i]->refuel(amount))
                    cout << "Refueled " << vehicleName << " with " << amount << " units.\n";
                return;
            }
        }
        cout << "Vehicle " << vehicleName << " not found.\n";
    }

    void displayVehicleInfo()
    {
        if (numofVehiclesAdded == 0)
        {
            cout << "No vehicles available.\n";
            return;
        }
        cout << "\n=== Vehicles ===\n";
        for (int i = 0; i < numofVehiclesAdded; i++)
        {
            cout << "Name: " << vehicles[i]->name << "\n";
            cout << "Type: ";
            switch (vehicles[i]->type)
            {
            case SHUTTLE:
                cout << "SHUTTLE";
                break;
            case ROVER:
                cout << "ROVER";
                break;
            case SPACE_STATION:
                cout << "SPACE_STATION";
                break;
            case FREIGHTER:
                cout << "FREIGHTER";
                break;
            case PROBE:
                cout << "PROBE";
                break;
            default:
                cout << "UNKNOWN";
            }
            cout << "\nFuel: " << vehicles[i]->fuelLevel << "\nCrew: ";
            for (int j = 0; j < vehicles[i]->crewCapacity; j++)
            {
                if (vehicles[i]->currentCrew[j] != nullptr)
                    cout << vehicles[i]->currentCrew[j]->name << ", ";
            }
            cout << "\n--------------------\n";
        }
    }
};

int main()
{
    ResourceManager resourceSystem;
    CrewManager crewSystem;
    VehicleManager vehicleSystem;

    int choice;
    bool gameRunning = true;
    int missionsCompleted = 0;
    bool victory = false;

    Vehicle availableVehicles[] = {
        {"Space Shuttle", SHUTTLE, 5000},
        {"Mars Rover", ROVER, 2000},
        {"Orbital Station", SPACE_STATION, 10000},
        {"Cargo Freighter", FREIGHTER, 8000},
        {"Exploration Probe", PROBE, 1000}};

    Resource gameResources[10];
    CrewMember gameCrew[10];
    Vehicle playerVehicles[10];
    int resCount = 0, crewCount = 0, vehicleCount = 0;

    cout << "=== SPACE MISSION SIMULATOR ===" << endl;
    cout << "Goal: Complete 3 missions using predefined resources!\n";

    while (gameRunning)
    {
        cout << "\n=== MAIN MENU ==="
             << "\n1. Add Resources"
             << "\n2. Recruit Crew"
             << "\n3. Acquire Vehicle"
             << "\n4. Launch Mission"
             << "\n5. View Status"
             << "\n6. Quit"
             << "\nChoice: ";
        cin >> choice;

        if (choice == 1)
        {
            cout << "\nAvailable Resource Types:\n"
                 << "0. FUEL\n1. FOOD\n2. WATER\n3. MEDICAL_SUPPLIES\n"
                 << "Select resource type: ";
            int resType;
            cin >> resType;

            cout << "Enter quantity: ";
            double quantity;
            cin >> quantity;

            gameResources[resCount].type = static_cast<ResourceType>(resType);
            gameResources[resCount].quantity = quantity;
            resourceSystem.addResource(&gameResources[resCount]);
            resCount++;
            cout << "Resources added!\n";
        }
        else if (choice == 2)
        {
            if (crewCount >= 10)
            {
                cout << "Maximum crew reached!\n";
                continue;
            }

            cout << "\nEnter crew member details:\n";
            cout << "Name: ";
            cin.ignore();
            getline(cin, gameCrew[crewCount].name);

            cout << "Role: ";
            getline(cin, gameCrew[crewCount].role);

            cout << "Rank: ";
            getline(cin, gameCrew[crewCount].rank);

            cout << "Experience (years): ";
            cin >> gameCrew[crewCount].experienceYears;

            crewSystem.addCrewMember(&gameCrew[crewCount]);
            crewCount++;
            cout << "Crew member recruited!\n";
        }
        else if (choice == 3)
        {
            cout << "\nAvailable Vehicles:\n";
            for (int i = 0; i < 5; i++)
            {
                cout << i << ". " << availableVehicles[i].name
                     << " (Fuel: " << availableVehicles[i].fuelLevel << ")\n";
            }

            cout << "Select vehicle (0-4): ";
            int vehicleChoice;
            cin >> vehicleChoice;

            if (vehicleChoice >= 0 && vehicleChoice < 5)
            {
                playerVehicles[vehicleCount] = availableVehicles[vehicleChoice];
                vehicleSystem.addVehicle(&playerVehicles[vehicleCount]);
                vehicleCount++;
                cout << "Vehicle acquired!\n";
            }
            else
            {
                cout << "Invalid selection!\n";
            }
        }
        else if (choice == 4)
        {
            cout << "\nAvailable Mission Types:" << "\n0. EXPLORATION\n1. TRANSPORT\n2. DEFENSE" << "\n3. REPAIR\n4. COLONIZATION" << "\nSelect mission type: ";
            int missionType;
            cin >> missionType;

            const int FUEL_NEEDED = 100 + (missionType * 100);
            const int FOOD_NEEDED = 100 + (missionType * 50);

            bool hasFuel = false, hasFood = false;
            for (int i = 0; i < resCount; i++)
            {
                if (gameResources[i].type == FUEL && gameResources[i].quantity >= FUEL_NEEDED)
                    hasFuel = true;
                if (gameResources[i].type == FOOD && gameResources[i].quantity >= FOOD_NEEDED)
                    hasFood = true;
            }

            if (!hasFuel || !hasFood || vehicleCount == 0)
            {
                cout << "Mission failed! Requirements not met!\n";
                if (!hasFuel)
                    cout << "- Need " << FUEL_NEEDED << " FUEL\n";
                if (!hasFood)
                    cout << "- Need " << FOOD_NEEDED << " FOOD\n";
                if (vehicleCount == 0)
                    cout << "- Need at least 1 vehicle\n";
                continue;
            }

            resourceSystem.consumeResource("FUEL", FUEL_NEEDED);
            resourceSystem.consumeResource("FOOD", FOOD_NEEDED);

            missionsCompleted++;
            cout << "Mission successful! Total: " << missionsCompleted << "/3\n";

            if (missionsCompleted >= 3)
            {
                victory = true;
                gameRunning = false;
            }
        }
        else if (choice == 5)
        {
            cout << "\n=== COLONY STATUS ===" << endl;
            resourceSystem.displayResources();
            crewSystem.displayCrewInfo();
            vehicleSystem.displayVehicleInfo();
            cout << "Completed Missions: " << missionsCompleted << "/3" << endl;
        }
        else if (choice == 6)
        {
            gameRunning = false;
        }
        else
        {
            cout << "Invalid choice!\n";
        }
    }

    if (victory)
    {
        cout << "\n=== VICTORY! ===" << endl;
        cout << "You've successfully completed 3 space missions!\n";
    }
    else
    {
        cout << "\n=== GAME OVER ===" << endl;
        cout << "Mission failed to establish colony!\n";
    }

    return 0;
}